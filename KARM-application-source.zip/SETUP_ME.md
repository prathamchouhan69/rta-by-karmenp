# Connect real Zoho Books

1. Open `api-console.zoho.in`, choose **Add Client**, then choose **Self Client**.
2. Generate the smallest Books scopes needed by the endpoint map and copy the code.
3. Run `node scripts/zoho-exchange-code.mjs` and enter the client details when asked.
4. Find the Organisation ID in Zoho Books → Settings → Organisation Profile.
5. Put secrets in the proxy environment, set `ZOHO_MODE=live`, and never commit them.
6. Restart the proxy and complete `reports/zoho/LIVE_CHECKLIST.md`.

Until this is done, keep practice mode on.
