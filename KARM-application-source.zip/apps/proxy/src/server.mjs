import { serve } from '@hono/node-server';
import { Hono } from 'hono';
const app = new Hono();
const contacts = [
  { contact_id: 'c1', contact_name: 'Dilip Buildcon Ltd', contact_type: 'customer', outstanding: '64944.84', outstanding_formatted: '₹64,944.84' },
  { contact_id: 'c2', contact_name: 'Apex Infra', contact_type: 'customer', outstanding: '18400.00', outstanding_formatted: '₹18,400.00' },
  { contact_id: 'c3', contact_name: 'Narmada Projects', contact_type: 'customer', outstanding: '9080.00', outstanding_formatted: '₹9,080.00' }
];
const items = [
  { item_id: 'i1', name: 'Stone dust', hsn_or_sac: '2517', rate: '950.00', rate_formatted: '₹950.00' },
  { item_id: 'i2', name: 'River sand', hsn_or_sac: '2505', rate: '1250.00', rate_formatted: '₹1,250.00' }
];
const invoices = [{ invoice_id: 'inv-golden', invoice_number: 'INV-KE-270031', customer_name: 'Dilip Buildcon Ltd', total: '64944.84', total_formatted: '₹64,944.84', balance: '64944.84', balance_formatted: '₹64,944.84', status: 'overdue' }];
const idempotentResponses = new Map();
const audit = [];
app.use('*', async (c, next) => {
  c.header('X-Content-Type-Options','nosniff');
  c.header('Referrer-Policy','no-referrer');
  c.header('Cache-Control','no-store');
  c.header('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'");
  c.header('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  await next();
});
app.get('/api/v1/health', (c) => c.json({ok:true,data:{mode:process.env.ZOHO_MODE ?? 'mock',service:'karm-proxy'}}));
app.get('/api/v1/organization', (c) => c.json({ok:true,data:{name:'Karm Enterprises',mode:'practice'}}));
app.get('/api/v1/contacts', (c) => c.json({ ok: true, data: contacts }));
app.get('/api/v1/contacts/:id', (c) => {
  const contact = contacts.find((entry) => entry.contact_id === c.req.param('id'));
  return contact ? c.json({ ok: true, data: contact }) : c.json({ ok: false, error: { code: 'NOT_FOUND', message: 'Contact not found' } }, 404);
});
app.get('/api/v1/items', (c) => c.json({ ok: true, data: items }));
app.get('/api/v1/taxes', (c) => c.json({ ok: true, data: [{ tax_id: 'gst18', tax_name: 'GST 18%', tax_percentage: '18.000' }, { tax_id: 'gst5', tax_name: 'GST 5%', tax_percentage: '5.000' }] }));
app.get('/api/v1/invoices', (c) => c.json({ ok: true, data: invoices }));
app.get('/api/v1/search', (c) => {
  const query = c.req.query('q')?.toLowerCase() ?? '';
  return c.json({ ok: true, data: { contacts: contacts.filter((entry) => entry.contact_name.toLowerCase().includes(query)), items: items.filter((entry) => entry.name.toLowerCase().includes(query)), invoices: invoices.filter((entry) => entry.invoice_number.toLowerCase().includes(query)) } });
});
app.get('/api/v1/news', (c) => c.json({ ok: true, data: [{ title: 'Practice mode is active', url: '/settings', source: 'KARM OS' }] }));
app.get('/api/v1/audit', (c) => c.json({ ok: true, data: audit }));
app.post('/api/v1/invoices', async (c) => {
  const key = c.req.header('Idempotency-Key');
  if (!key) return c.json({ ok: false, error: { code: 'IDEMPOTENCY_REQUIRED', message: 'Idempotency-Key is required for writes' } }, 422);
  if (idempotentResponses.has(key)) return c.json(idempotentResponses.get(key));
  const body = await c.req.json();
  const computedFields = ['total', 'sub_total', 'tax_total', 'balance', 'round_off', 'tax_amount'];
  const found = computedFields.find((field) => Object.hasOwn(body, field));
  if (found) return c.json({ ok: false, error: { code: 'COMPUTED_FIELD', message: `Computed field "${found}" must be calculated by Zoho Books` } }, 422);
  const response = { ok: true, data: { invoice_id: `draft-${key.slice(0, 8)}`, status: 'draft', message: 'Draft accepted for Zoho Books' } };
  idempotentResponses.set(key, response);
  audit.push({ time: new Date().toISOString(), route: '/api/v1/invoices', idempotency_key: key, document_id: response.data.invoice_id, result: 'accepted' });
  return c.json(response, 201);
});
app.all('/api/v1/*', (c) => c.json({ok:false,error:{code:'NOT_IMPLEMENTED',message:'This practice endpoint is not enabled yet.',hint:'Use the practice app or connect Zoho before live writes.'}}, 501));
serve({fetch:app.fetch,port:Number(process.env.PORT ?? 8787)});
console.log('KARM proxy listening on http://localhost:8787');
