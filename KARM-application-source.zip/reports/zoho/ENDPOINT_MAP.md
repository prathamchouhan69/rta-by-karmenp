# Zoho endpoint map

The local proxy keeps this map explicit. Endpoint availability must be confirmed against
the owner's Zoho Books organisation before switching from practice to live mode.

| Document | Endpoint | Status |
|---|---|---|
| Tax invoice | `/invoices` | AVAILABLE |
| Estimate | `/estimates` | AVAILABLE |
| Sales order | `/salesorders` | AVAILABLE |
| Delivery challan | `/deliverychallans` | VERIFY LIVE |
| Credit note | `/creditnotes` | AVAILABLE |
| Customer payment | `/customerpayments` | AVAILABLE |
| Purchase order | `/purchaseorders` | AVAILABLE |
| Bill | `/bills` | AVAILABLE |
| Vendor credit | `/vendorcredits` | AVAILABLE |
| Vendor payment | `/vendorpayments` | AVAILABLE |
| Expense | `/expenses` | AVAILABLE |
| Journal | `/journals` | AVAILABLE |
| Statements and ledgers | Zoho saved reports | ONLY IN ZOHO BOOKS UI unless exposed by the organisation |
