import { spawn } from 'node:child_process';
import { request } from 'node:http';

const proxy = spawn(process.execPath, ['apps/proxy/src/server.mjs'], {
  stdio: ['ignore', 'pipe', 'pipe'],
  env: { ...process.env, PORT: '8787', ZOHO_MODE: 'mock' }
});
let proxyOutput = '';
proxy.stdout.on('data', (chunk) => { proxyOutput += chunk; });
proxy.stderr.on('data', (chunk) => { proxyOutput += chunk; });

const call = (path, method = 'GET', body, headers = {}) => new Promise((resolve, reject) => {
  const payload = body === undefined ? undefined : JSON.stringify(body);
  const req = request({
    hostname: '127.0.0.1', port: 8787, path, method,
    headers: { ...(payload === undefined ? {} : { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) }), ...headers }
  }, (res) => {
    let responseBody = '';
    res.setEncoding('utf8');
    res.on('data', (chunk) => { responseBody += chunk; });
    res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(responseBody) }));
  });
  req.on('error', reject);
  if (payload !== undefined) req.write(payload);
  req.end();
});

const waitForProxy = async () => {
  for (let attempt = 0; attempt < 30; attempt += 1) {
    try { return await call('/api/v1/health'); } catch { await new Promise((resolve) => setTimeout(resolve, 100)); }
  }
  throw new Error(`proxy did not start: ${proxyOutput}`);
};

try {
  const health = await waitForProxy();
  const invoices = await call('/api/v1/invoices');
  const taxes = await call('/api/v1/taxes');
  const search = await call('/api/v1/search?q=dilip');
  const computed = await call('/api/v1/invoices', 'POST', { customer_id: 'c1', total: '12.00' }, { 'Idempotency-Key': 'e2e-computed' });
  const firstWrite = await call('/api/v1/invoices', 'POST', { customer_id: 'c1', line_items: [{ item_id: 'i1', quantity: '1', rate: '950.00' }] }, { 'Idempotency-Key': 'e2e-idempotent' });
  const secondWrite = await call('/api/v1/invoices', 'POST', { customer_id: 'c1', line_items: [{ item_id: 'i1', quantity: '1', rate: '950.00' }] }, { 'Idempotency-Key': 'e2e-idempotent' });
  if (health.status !== 200 || health.body.ok !== true) throw new Error('health check failed');
  if (invoices.body.data[0]?.total_formatted !== '₹64,944.84') throw new Error('golden invoice check failed');
  if (taxes.status !== 200 || taxes.body.data[0]?.tax_percentage !== '18.000') throw new Error('tax contract failed');
  if (search.status !== 200 || search.body.data.contacts.length !== 1) throw new Error('search contract failed');
  if (computed.status !== 422 || computed.body.error?.code !== 'COMPUTED_FIELD') throw new Error('computed-field rejection failed');
  if (firstWrite.status !== 201 || JSON.stringify(firstWrite.body) !== JSON.stringify(secondWrite.body)) throw new Error('idempotency check failed');
  console.log('E2E smoke PASS: health, golden invoice, computed-field rejection, idempotency');
} finally {
  proxy.kill('SIGTERM');
}
